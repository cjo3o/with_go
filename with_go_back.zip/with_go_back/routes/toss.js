const express = require('express');
const router = express.Router();
const axios = require('axios');

const TossKey = process.env.VITE_TOSS_API_KEY;

router.post("/confirm", async (req, res) => {
    const { paymentKey, orderId, amount } = req.body;

    try {
        const response = await axios.post(
            "https://api.tosspayments.com/v1/payments/confirm",
            {
                paymentKey,
                orderId,
                amount,
            },
            {
                headers: {
                    Authorization: `Basic ${Buffer.from(TOSS_SECRET_KEY + ":").toString("base64")}`,
                    "Content-Type": "application/json",
                },
            }
        );

        res.status(200).json(response.data); // 승인 성공
    } catch (err) {
        console.error("❌ 결제 승인 실패:", err.response?.data || err.message);
        res.status(err.response?.status || 500).json(err.response?.data || { message: "서버 오류" });
    }
});

module.exports = router;